﻿CV MAU SCAPP â€” DU LIEU TONG HOP
Nguon: test-files/cv-mau-a7 trong repo SCApp.
Khong su dung CV that hoac thong tin ca nhan de test.
De upload can chon nguon ho so va xac nhan dong y theo quy dinh ung dung.
